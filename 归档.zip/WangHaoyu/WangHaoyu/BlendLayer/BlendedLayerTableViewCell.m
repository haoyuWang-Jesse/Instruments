//
//  BlendedLayerTableViewCell.m
//  WangHaoyu
//
//  Created by haoyu3 on 2016/12/15.
//  Copyright © 2016年 haoyu3. All rights reserved.
//

#import "BlendedLayerTableViewCell.h"

@implementation BlendedLayerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self addCustomView];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (void)addCustomView {
    for (id tempView in self.contentView.subviews) {
        [tempView removeFromSuperview];
    }
    
    self.contentView.backgroundColor = [UIColor whiteColor];
    
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    
    //NOTE:1 设置透明度
    
    UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(0,10, screenWidth, screenWidth/2)];
    image.image = [UIImage imageNamed:@"2.jpg"];
    [self.contentView addSubview:image];
    
    /*
    UIView *bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(image.frame) - 80, screenWidth, 60)];
    bottomView.backgroundColor = [UIColor blackColor];
    bottomView.alpha = 1;
    [image addSubview:bottomView];
    */
    /*
    //NOTE:2 设置颜色
    UILabel *bottomLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 80, screenWidth, 40)];
    bottomLabel.text = @"新浪娱乐新浪娱乐新浪娱乐新浪娱乐新浪娱乐新浪娱乐新浪娱乐新浪娱乐";
    bottomLabel.textColor = [UIColor blackColor];
    bottomLabel.backgroundColor = [UIColor whiteColor];
    bottomLabel.layer.masksToBounds = YES;

    [self.contentView addSubview:bottomLabel];
    */
    /*
     !!!:Wang haoyu -
        1 label的内容是中文,label实际渲染区域要大于label的size，最外层多了一个sublayer，如果不设置第二行label的边缘外层灰出现图层混合的红色，因此需要在label内容是中文的情况下加第二句
        2 单独使用bottomLabel.layer.masksToBounds = YES，不会触发离屏渲染，同corRidious属性才会引起离屏渲染。
    */
    
    //NOTE:3 imageView的特殊性
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((screenWidth - 85)/2, screenWidth/4 - 40, 85, 60)];
    imageView.image = [UIImage imageNamed:@"22.png"];
    imageView.alpha = 1;
    imageView.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:imageView];
    
    
    //RN  使用opacity属性要慎重
      //  应该主动为组件添加背景色
    
}

+ (CGFloat)heightForRow {
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    return screenWidth/2 + 10 ;
}

@end
