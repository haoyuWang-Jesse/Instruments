//
//  ViewController.m
//  WangHaoyu
//
//  Created by haoyu3 on 2016/12/14.
//  Copyright © 2016年 haoyu3. All rights reserved.
//

#import "ViewController.h"
#import "NativeViewController.h"
#import "OffScreenViewController.h"
#import "MisalignedViewController.h"
#import "RasterRizeViewController.h"

@interface ViewController ()

@property (nonatomic, strong) UIButton *native;
@property (nonatomic, strong) UIButton *rnButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    [self createCustomView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)createCustomView {
    //native
    self.native = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.native setTitle:@"native" forState:UIControlStateNormal];
    [self.native addTarget:self action:@selector(pushPage:) forControlEvents:UIControlEventTouchDown];
    self.native.layer.borderColor = [UIColor blackColor].CGColor;
    self.native.frame = CGRectMake((self.view.frame.size.width - 100)/2,64, 100, 40);
    [self.native setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.native.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:self.native];
    //rn
    self.rnButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.rnButton setTitle:@"rn" forState:UIControlStateNormal];
    [self.rnButton addTarget:self action:@selector(pushPage:) forControlEvents:UIControlEventTouchDown];
    self.rnButton.layer.borderColor = [UIColor blackColor].CGColor;
    self.rnButton.frame = CGRectMake((self.view.frame.size.width - 100)/2,164, 100, 40);
    [self.rnButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.rnButton.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:self.rnButton];
    
    self.native.tag = 1000;
}

#pragma mark - button action

- (void)pushPage:(UIButton *)button {
    if(button.tag == 1000) {
        //光栅化
        //[self presentViewController:[RasterRizeViewController new] animated:YES completion:nil];
        
        //离屏渲染
        //[self presentViewController:[OffScreenViewController new] animated:YES completion:nil];
        
        //图层混合
        //[self presentViewController:[NativeViewController new] animated:YES completion:nil];

        //图片尺寸
        [self presentViewController:[MisalignedViewController new] animated:YES completion:nil];

        return;
    }
    else {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"SinaEnt://ent.sina.com"] options:@{} completionHandler:nil];
    }
    
}

@end
