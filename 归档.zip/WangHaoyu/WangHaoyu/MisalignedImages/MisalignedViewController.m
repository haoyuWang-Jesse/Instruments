
//
//  MisalignedViewController.m
//  WangHaoyu
//
//  Created by haoyu3 on 2016/12/15.
//  Copyright © 2016年 haoyu3. All rights reserved.
//

#import "MisalignedViewController.h"

@interface MisalignedViewController ()

@end

@implementation MisalignedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self addCustomView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addCustomView {
    //NOTE:同尺寸展示
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake((screenWidth - 90)/2, 80, 90, 60)];
    imageview.image = [UIImage imageNamed:@"tang.jpg"];
    imageview.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:imageview];
    
    //NOTE:成比例放缩
    UIImageView *imageview2 = [[UIImageView alloc] initWithFrame:CGRectMake((screenWidth - 180)/2, 280, 180, 120)];
    imageview2.image = [UIImage imageNamed:@"tang.jpg"];
    imageview2.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:imageview2];
    
    
}


@end
