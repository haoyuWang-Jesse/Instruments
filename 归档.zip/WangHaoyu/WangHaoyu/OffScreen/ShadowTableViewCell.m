//
//  ShadowTableViewCell.m
//  WangHaoyu
//
//  Created by haoyu3 on 2016/12/15.
//  Copyright © 2016年 haoyu3. All rights reserved.
//

#import "ShadowTableViewCell.h"
#import "UIImage+RoundedCorner.h"


@implementation ShadowTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self addCustomView];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (void)addCustomView {
    for (id tempView in self.contentView.subviews) {
        [tempView removeFromSuperview];
    }
    
    self.contentView.backgroundColor = [UIColor whiteColor];
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    //label
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(110, 10, screenWidth - 110, 40)];
    label.font = [UIFont systemFontOfSize:17.0f];
    label.backgroundColor = [UIColor whiteColor];
    label.text = @"新浪娱乐新浪娱乐新浪娱乐新浪娱乐新浪娱乐";
    [self.contentView addSubview:label];
    
    
    UIImageView *leftImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 60, 60)];
    leftImageView.image = [UIImage imageNamed:@"tang.jpg"];
    [self.contentView addSubview:leftImageView];
    
    /*
    CALayer *imageViewLayer = leftImageView.layer;
    imageViewLayer.shadowColor = [UIColor blackColor].CGColor;
    imageViewLayer.shadowOpacity = 1.0;
    imageViewLayer.shadowRadius = 2.0;
    
    CALayer *labelLayer = label.layer;
    labelLayer.shadowColor = [UIColor blackColor].CGColor;
    labelLayer.shadowOpacity = 1.0;
    labelLayer.shadowRadius = 2.0;
   */
    /*
    //NOTE:触发离屏渲染的操作一  -- layer.shadow*
    imageViewLayer.shadowOffset = CGSizeMake(1.0, 1.0);
    labelLayer.shadowOffset = CGSizeMake(1.0, 1.0);
    */
    
    /*
    //解决办法：使用shadowPath 替换 shadowOffset
    imageViewLayer.shadowPath = CGPathCreateWithRect(leftImageView.frame, NULL);
    label.layer.shadowPath = CGPathCreateWithRect(label.frame, NULL);
    */
    /*
     使用shadowPath高效的原因分析：
        1、cpu来执行：这里提到的offScreen rendering，是指由GPU来完成的，但实际上有的offScreen rendering是通过cpu来执行的，例如Core Graphics 对象 和drawReact等,shadowPath是一个CGPathRef类型的对象，也就是指向CGPath的指针。CGPath是一个Core Graphics对象。所以使用shadowPath来生成阴影实际上实在cpu中执行离屏渲染的操作。
        2、CGPath是一个Core Graphics对象，用来指定任意的一个矢量图形。我们可以通过这个属性独立于图层形状之外指定阴影的形状。
        3、RN中目前不支持shadowPath，但是可以定位到导致界面卡顿原因，对症下药。
     */
    
    
    //NOTE:触发离屏渲染的操作二 --  圆角
    /*
     leftImageView.image = [UIImage imageNamed:@"tang.jpg"];
    CALayer *imageViewLayer = leftImageView.layer;
    imageViewLayer.cornerRadius = 30;
    imageViewLayer.masksToBounds = YES;
    imageViewLayer.shouldRasterize = YES;
    */
    
    //label.layer.cornerRadius = 10;
    //label.layer.masksToBounds = YES;
    
    //解决办法：1、使用带圆角中间透明的图覆盖，但是会引起新的问题 -- blended rendering
           // 2.1使用GraphicsContext或者UIBezierPath来切割图片，将image切割成一张原型图片，然后交给imageview显示
    leftImageView.image = [[UIImage imageNamed:@"tang.jpg"] imageWithRoundedCornersAndSize:CGSizeMake(90, 60) andCornerRadius:10];
            //2.2 在iOS10测试，UIImageView中设置图片圆角不会触发离屏渲染。
    
    
    //NOTE:2.3 这种方式更高效一些:  UIBezierPath 和 Core Graphics，而前者所属UIKit，其实是对Core Graphics框架关于path的进一步封装，实际上执行还是通过cpu。同前面提到的shadowPath是同样的道理
    /*
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:label.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(7, 7)];
    
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = label.bounds;
    maskLayer.path = maskPath.CGPath;
    label.layer.mask  = maskLayer;
    label.backgroundColor = [UIColor lightGrayColor];
    */
    
}

+ (CGFloat)heightForRow {
    return 110;
}

@end
