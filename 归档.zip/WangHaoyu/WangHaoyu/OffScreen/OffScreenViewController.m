//
//  OffScreenViewController.m
//  WangHaoyu
//
//  Created by haoyu3 on 2016/12/15.
//  Copyright © 2016年 haoyu3. All rights reserved.
//

#import "OffScreenViewController.h"
#import "ShadowTableViewCell.h"

@interface OffScreenViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableview;

@end

@implementation OffScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self addCustomView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)addCustomView {
    self.view.backgroundColor = [UIColor whiteColor];
    self.tableview = [UITableView new];
    self.tableview.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 64);
    self.tableview.delegate = self;
    self.tableview.dataSource = self;
    [self.view addSubview:self.tableview];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  100;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"cell";
    ShadowTableViewCell *cell ;
    if (cell == nil) {
        cell = [[ShadowTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    //cell.layer.shouldRasterize = YES;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [ShadowTableViewCell heightForRow];
}

@end
