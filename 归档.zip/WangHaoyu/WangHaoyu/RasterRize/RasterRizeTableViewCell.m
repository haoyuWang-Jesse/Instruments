//
//  RasterRizeTableViewCell.m
//  WangHaoyu
//
//  Created by haoyu3 on 2016/12/15.
//  Copyright © 2016年 haoyu3. All rights reserved.
//

#import "RasterRizeTableViewCell.h"

@implementation RasterRizeTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addCustomView];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

- (void)addCustomView {
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    self.backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 200)];
    UIView *view1 = [self addSignalViewToSuperView:self.backgroundView withShadow:YES];
    [self.backgroundView addSubview:view1];
    UIView *view2 = [self addSignalViewToSuperView:self.backgroundView withShadow:NO];
    [self.backgroundView addSubview:view2];
    [self.contentView addSubview:self.backgroundView];
}

- (UIView *)addSignalViewToSuperView:(UIView*)targetView withShadow:(BOOL)shadow {
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat height = shadow ? 30 : 130;
    UIView *backview1 = [[UIView alloc] initWithFrame:CGRectMake(0, height, screenWidth, 100)];
    backview1.backgroundColor = [UIColor lightGrayColor];
    [targetView addSubview:backview1];
    for (int i = 0; i< 5; i++) {
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(i*70, 10, 60, 60)];
        imageview.image = [UIImage imageNamed:@"tang.jpg"];
        
        CALayer *imageviewLayer = imageview.layer;
        imageviewLayer.shadowColor = [UIColor blackColor].CGColor;
        imageviewLayer.shadowOpacity = 1.0;
        imageviewLayer.shadowRadius = 2.0;
        imageviewLayer.shadowOffset = CGSizeMake(1.0, 1.0);
        
        //NOTE:光栅化
        imageviewLayer.shouldRasterize = YES;
        
        
        /*
         if(shadow) {
         //shadow
         CALayer *imageviewLayer = imageview.layer;
         imageviewLayer.shadowColor = [UIColor blackColor].CGColor;
         imageviewLayer.shadowOpacity = 1.0;
         imageviewLayer.shadowRadius = 2.0;
         imageviewLayer.shadowOffset = CGSizeMake(1.0, 1.0);
         }
         else {
         
         //radious
         imageview.layer.cornerRadius = 30;
         imageview.layer.masksToBounds = YES;
         imageview.layer.shouldRasterize = YES;
         
         }
         */
        
        [backview1 addSubview:imageview];
    }
    return backview1;
}

+(CGFloat)heightForRow {
    return 210;
}

@end
